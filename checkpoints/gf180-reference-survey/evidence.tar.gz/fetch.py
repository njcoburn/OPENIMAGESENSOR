import urllib.request,json
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
P=Path(__file__).resolve().parent
repos=['TinyTapeout/tt-multiplexer','iic-jku/gf180mcu-jku-projects','ishi-kai/ISHI-KAI_Multiple_Projects_WaferSapce-GF180-1','RTimothyEdwards/gf180mcu_ocd_io']
def fetch(repo):
 ref='30c3f44' if repo=='TinyTapeout/tt-multiplexer' else 'main'
 try:
  d=json.load(urllib.request.urlopen(f'https://api.github.com/repos/{repo}/git/trees/{ref}?recursive=1',timeout=30));(P/(repo.replace('/','__')+'-tree.json')).write_text(json.dumps(d));print(repo,d['sha'])
  paths=[x['path'] for x in d['tree'] if x['type']=='blob' and any(k in x['path'].lower() for k in ['spice','padring','padframe','simulation','testbench'])];print('\n'.join(paths[:80]))
 except Exception as e:print(repo,str(e))
with ThreadPoolExecutor(max_workers=4) as ex:list(ex.map(fetch,repos))
