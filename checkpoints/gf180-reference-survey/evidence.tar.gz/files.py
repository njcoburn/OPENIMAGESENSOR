import urllib.request,json,hashlib
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
P=Path(__file__).resolve().parent
sets={'TinyTapeout/tt-multiplexer':['cfg/gf180mcuD.yaml','ol2/tt_top/tt_gf_wrapper.v','ol2/tt_top/build.py','docs/INFO.md'],'iic-jku/gf180mcu-jku-projects':['src/chip_top.sv','librelane/config.yaml','Makefile','README.md'],'ishi-kai/ISHI-KAI_Multiple_Projects_WaferSapce-GF180-1':['README.md','schematic/README.md'],'RTimothyEdwards/gf180mcu_ocd_io':['netlist/schematic/gf180mcu_ocd_io__cor.spice','netlist/schematic/gf180mcu_ocd_io__dvdd.spice']}
def fetch(t):
 repo,file=t;rev=json.loads((P/(repo.replace('/','__')+'-tree.json')).read_text())['sha'];u=f'https://raw.githubusercontent.com/{repo}/{rev}/{file}'
 try:
  b=urllib.request.urlopen(u,timeout=30).read();p=P/repo.replace('/','__')/file;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);return dict(repo=repo,commit=rev,path=file,url=u,sha256=hashlib.sha256(b).hexdigest())
 except Exception as e:return dict(url=u,error=str(e))
with ThreadPoolExecutor(max_workers=6) as ex:r=list(ex.map(fetch,[(repo,f) for repo,fs in sets.items() for f in fs]))
(P/'sources.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2))
