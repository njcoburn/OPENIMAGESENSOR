import urllib.request,json,hashlib
from pathlib import Path
P=Path(__file__).resolve().parent
repo='wafer-space/gf180mcu';d=json.load(urllib.request.urlopen(f'https://api.github.com/repos/{repo}/git/trees/1.6.6?recursive=1',timeout=30));(P/'wafer-space__gf180mcu-tree.json').write_text(json.dumps(d));print('PDK tag 1.6.6',d['sha'])
files=[x['path'] for x in d['tree'] if x['type']=='blob' and 'ws_io' in x['path'] and x['path'].endswith(('.spice','.v'))];print('\n'.join(files[:40]))
for f in files:
 if 'spice' not in f:continue
 b=urllib.request.urlopen(f'https://raw.githubusercontent.com/{repo}/{d["sha"]}/{f}',timeout=30).read();p=P/'wafer-space__gf180mcu'/f;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
repo='TinyTapeout/tt-multiplexer';rev='30c3f44bcb23ffdad2c2f97edd4c4fe3fc6a87bf';f='rtl/tt_gf_gpio.v';b=urllib.request.urlopen(f'https://raw.githubusercontent.com/{repo}/{rev}/{f}',timeout=30).read();p=P/'TinyTapeout__tt-multiplexer'/f;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
